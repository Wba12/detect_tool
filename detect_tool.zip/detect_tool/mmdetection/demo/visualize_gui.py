import json
import matplotlib.pyplot as plt
import sys
import os
from collections import OrderedDict


def load_data(log):
    dict_list = list()
    loss_rpn_bbox = list()
    loss_rpn_cls = list()
    loss_bbox = list()
    loss_cls = list()
    loss = list()
    acc = list()
    for line in log:
        info = json.loads(line)  # 每一行字典
        # print('info:{}'.format(info))
        # print('info.keys():{}'.format(info.keys()))
        if len(info.keys()) != 11:
            continue
        else:
            dict_list.append(info)  # 将每一行字典放入列表

    for i in range(1, len(dict_list)):
        for value, key in dict(dict_list[i]).items():
            # ------------find key for every iter-------------------#
            loss_rpn_cls_value = dict(dict_list[i])['loss_rpn_cls']
            loss_rpn_bbox_value = dict(dict_list[i])['loss_rpn_bbox']
            loss_bbox_value = dict(dict_list[i])['loss_bbox']
            loss_cls_value = dict(dict_list[i])['loss_cls']
            loss_value = dict(dict_list[i])['loss']
            acc_value = dict(dict_list[i])['acc']
            # -------------list append------------------------------#
            loss_rpn_cls.append(loss_rpn_cls_value)
            loss_rpn_bbox.append(loss_rpn_bbox_value)
            loss_bbox.append(loss_bbox_value)
            loss_cls.append(loss_cls_value)
            loss.append(loss_value)
            acc.append(acc_value)
            # -------------clear repeated value---------------------#
    loss_rpn_cls = list(OrderedDict.fromkeys(loss_rpn_cls))
    loss_rpn_bbox = list(OrderedDict.fromkeys(loss_rpn_bbox))
    loss_bbox = list(OrderedDict.fromkeys(loss_bbox))
    loss_cls = list(OrderedDict.fromkeys(loss_cls))
    loss = list(OrderedDict.fromkeys(loss))
    acc = list(OrderedDict.fromkeys(acc))
    return [loss_rpn_bbox, loss_rpn_cls, loss_bbox, loss_cls, loss, acc]


def show_chart(data, path, font_size, fig_size, title_size):
    # 绘图名称在这里更改
    # print('data:{}'.format(data))
    # print('path:{}'.format(path))
    (save_path, temp_filename) = os.path.split(path)
    (filename, extension) = os.path.splitext(temp_filename)
    plt.rcParams.update(font_size)

    plt.figure(figsize=fig_size)

    plt.subplot(321, title='loss_rpn_cls', ylabel='loss')
    plt.plot(data[1])
    plt.subplot(322, title='loss_rpn_bbox', ylabel='loss')
    plt.plot(data[0])

    plt.subplot(323, title='loss_cls', ylabel='loss')
    plt.plot(data[3])
    plt.subplot(324, title='loss_bbox', ylabel='loss')
    plt.plot(data[2])
    plt.subplot(325, title='total loss', ylabel='loss')
    plt.plot(data[4])
    plt.subplot(326, title='accuracy', ylabel='accuracy')
    plt.plot(data[5])
    plt.suptitle((filename + "\n training result"), fontsize=title_size)
    # plt.show()
    # print(save_path + '/' + filename + '_result.png')
    plt.savefig((path + '/' + 'visualize_result.png'))
    plt.clf()
