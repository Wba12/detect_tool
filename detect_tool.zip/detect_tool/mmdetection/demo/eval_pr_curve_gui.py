# =========================================================
# @purpose: plot PR curve by COCO API and mmdet API
# @date：   2020/12
# @version: v1.0
# @author： Xu Huasheng
# @github： https://github.com/xuhuasheng/mmdetection_plot_pr_curve
# =========================================================

import os
import time
import json
import numpy as np
import matplotlib.pyplot as plt
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

from mmengine.config import Config
from mmengine.fileio import load
from mmengine.registry import init_default_scope
from mmdet.registry import DATASETS
from mmdet.utils import replace_cfg_vals, update_data_root
import csv
def plot_pr_curve(config_file, result_file, save_path, metric="bbox"):
    """plot precison-recall curve based on testing results of pkl file.

        Args:
            config_file (list[list | tuple]): config file path.
            result_file (str): pkl file of testing results path.
            metric (str): Metrics to be evaluated. Options are
                'bbox', 'segm'.
    """
    # load config
    cfg = Config.fromfile(config_file)

    # replace the ${key} with the value of cfg.key
    cfg = replace_cfg_vals(cfg)

    # update data root according to MMDET_DATASETS
    update_data_root(cfg)


    init_default_scope(cfg.get('default_scope', 'mmdet'))


    # build dataset
    # dataset = DATASETS.build(cfg.test_dataloader.dataset)
    # print('dataset:{}'.format(dataset))
    # load result file in pkl format
    pkl_results = load(result_file)
    # print('pkl_results[0]:{}'.format(pkl_results[0]['pred_instances']))
    # labels = pkl_results[0]['pred_instances']['labels']
    # print('labels:{}'.format(labels))
    # print(labels[0])
    annotation_files = load(cfg.test_evaluator.ann_file)
    images = annotation_files["images"]

    # print('pkl_results[0]:{}'.format(pkl_results))
    json_path = 'results' + time.strftime('%Y%m%d%H%M%S')
    f = open(json_path + '.bbox.json', 'w')
    json_list = []
    for k in range(len(images)):
        img_info = pkl_results[k]["pred_instances"]
        if len(img_info["labels"]) == 0:
            continue
        else:
            for j in range(len(img_info["labels"])):
                bbox = img_info["bboxes"][j]
                score = img_info["scores"][j]
                category_id = img_info["labels"][j]
                data = {"image_id": k, "bbox": [float(bbox[0]), float(bbox[1]), float(bbox[2])-float(bbox[0]), float(bbox[3])-float(bbox[1])], "score": float(score), "category_id": int(category_id)+1}
                json_list.append(data)
    json.dump(json_list, f, ensure_ascii=False)
    f.close()

    # f.close()
    # json_results, _ = dataset.format_results(pkl_results)
    # initialize COCO instance
    # json_file = load(r'E:\CNN\mmdetection\demo\results.bbox.json')
    json_file = load(json_path + '.bbox.json')

    if not json_file:
        print('验证结果为空，不能绘制PR曲线/The testing results of the whole dataset is empty.')
    else:

        coco = COCO(annotation_file=cfg.test_evaluator.ann_file)
        coco_gt = coco
        coco_dt = coco_gt.loadRes(json_file)
        # initialize COCOeval instance
        coco_eval = COCOeval(coco_gt, coco_dt, metric)
        coco_eval.evaluate()
        coco_eval.accumulate()
        coco_eval.summarize()
        # extract eval data
        precisions = coco_eval.eval["precision"]
        '''
        precisions[T, R, K, A, M]
        T: iou thresholds [0.5 : 0.05 : 0.95], idx from 0 to 9
        R: recall thresholds [0 : 0.01 : 1], idx from 0 to 100
        K: category, idx from 0 to ...
        A: area range, (all, small, medium, large), idx from 0 to 3
        M: max dets, (1, 10, 100), idx from 0 to 2
        '''
        pr_array1 = precisions[0, :, 0, 0, 2]
        pr_array2 = precisions[1, :, 0, 0, 2]
        pr_array3 = precisions[2, :, 0, 0, 2]
        pr_array4 = precisions[3, :, 0, 0, 2]
        pr_array5 = precisions[4, :, 0, 0, 2]
        pr_array6 = precisions[5, :, 0, 0, 2]
        pr_array7 = precisions[6, :, 0, 0, 2]
        pr_array8 = precisions[7, :, 0, 0, 2]
        pr_array9 = precisions[8, :, 0, 0, 2]
        pr_array10 = precisions[9, :, 0, 0, 2]

        x = np.arange(0.0, 1.01, 0.01)
        # plot PR curve
        plt.plot(x, pr_array1, label="iou=0.5")
        plt.plot(x, pr_array2, label="iou=0.55")
        plt.plot(x, pr_array3, label="iou=0.6")
        plt.plot(x, pr_array4, label="iou=0.65")
        plt.plot(x, pr_array5, label="iou=0.7")
        plt.plot(x, pr_array6, label="iou=0.75")
        plt.plot(x, pr_array7, label="iou=0.8")
        plt.plot(x, pr_array8, label="iou=0.85")
        plt.plot(x, pr_array9, label="iou=0.9")
        plt.plot(x, pr_array10, label="iou=0.95")

        plt.xlabel("recall")
        plt.ylabel("precison")
        plt.xlim(0, 1.0)
        plt.ylim(0, 1.01)
        plt.grid(True)
        # plt.legend(loc="lower left")
        plt.legend(loc="upper right")
        plt.savefig(save_path+'/PR.png')
        # plt.show()
        os.remove(json_path + '.bbox.json')

        data_save = []
        data_save.append([x, pr_array1, pr_array2, pr_array3, pr_array4, pr_array5, pr_array6, pr_array7, pr_array8, pr_array9, pr_array10])
        with open('3_pr.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(data_save)


    


    

